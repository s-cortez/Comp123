import turtle

window = turtle.Screen()
myTurtle = turtle.Turtle()
window.bgcolor("lavender")
myTurtle.color("blue")
myTurtle.forward(50)
myTurtle.left(45)
myTurtle.forward(50)
myTurtle.left(157)
myTurtle.forward(93)
window.exitonclick()  # this last closes the window when user clicks
